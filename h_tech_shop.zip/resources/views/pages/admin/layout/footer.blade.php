{{-- <script src="{{URL::asset('resources/css_js_admin')}}/js/jquery.min.js"></script> --}}

<!-- Bootstrap Core JavaScript -->
<script src="{{URL::asset('resources/css_js_admin')}}/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="{{URL::asset('resources/css_js_admin')}}/js/metisMenu.min.js"></script>

<!-- Morris Charts JavaScript -->
<script src="{{URL::asset('resources/css_js_admin')}}/js/raphael.min.js"></script>
<script src="{{URL::asset('resources/css_js_admin')}}/js/morris.min.js"></script>
<script src="{{URL::asset('resources/css_js_admin')}}/js/morris-data.js"></script>

<!-- Custom Theme JavaScript -->
<script src="{{URL::asset('resources/css_js_admin')}}/js/startmin.js"></script>
