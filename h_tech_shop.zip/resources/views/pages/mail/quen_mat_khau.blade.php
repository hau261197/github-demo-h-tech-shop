<h3>Quên mật khẩu?</h3>
<p>Nhấp vào đây để lấy lại mật khẩu: <a href="{{url('khach-hang/quen-mat-khau/'.$token)}}">{{$token}}</a>  </p>
<p>Đường dẫn có hiệu lực trong 5 phút</p>
<h5>Nếu đây không phải là bạn hãy bỏ qua mail này!</h5>
