<div  id="footerSection">
    <div class="container">
        <div class="row">
			<div class="span3" >
				<div class="mapouter"><div class="gmap_canvas"><iframe class="gmap_iframe" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=270&amp;height=200&amp;hl=en&amp;q=76 xuân diệu&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe><a href="https://www.fridaynightfunkin.net/friday-night-funkin-mods-fnf-play-online/">FNF Mods</a></div><style>.mapouter{position:relative;text-align:right;width:270px;height:200px;}.gmap_canvas {overflow:hidden;background:none!important;width:270px;height:200px;}.gmap_iframe {width:270px!important;height:200px!important;}</style></div>
			</div>
			<div class="span3">
				<h5>ĐỊA CHỈ</h5>
				<p><span style="text-decoration: underline;">Văn phòng chính:</span>&nbsp;<span style="font-size:80%;">76 Xuân Diệu, Phường 14, Quận Tân Bình, Tp.HCM</span></p>
				<p><span style="text-decoration: underline;">Cửa hàng Gò Vấp:</span>&nbsp;<span style="font-size:80%;">2000 Phan Văn Trị, Phường 9, Quận Gò Vấp, Tp.HCM</span></p>
				<p><span style="text-decoration: underline;">Cửa hàng Tân Bình:</span>&nbsp;<span style="font-size:80%;">2000 Lạc Long Quân, Phường 8, Quận Tân Bình, Tp.HCM</span></p>
			</div>
			<div class="span3">
				<h5>LIÊN HỆ</h5>
				<p><span>Điện thoại:</span>&nbsp;<span style="font-size:80%;">0939237941 - (028) 2345 6789</span></p>
				<p><span>Fax:</span>&nbsp;<span style="font-size:80%;">028.23456789</span></p>
				<p><span >Email:</span>&nbsp;<span style="font-size:80%;">trunghaubt97@gmail.com</span></p>
			</div>
			<div id="socialMedia" class="span3 pull-right">
				<h5>VỀ CHÚNG TÔI</h5>
				<a href="https://www.facebook.com/hau.hatrung.31"><img width="60" height="60" src="{{URL::asset('resources/css/fontend')}}/themes/images/facebook.png" title="facebook" alt="facebook"/></a>
				<a href="https://twitter.com/home"><img width="60" height="60" src="{{URL::asset('resources/css/fontend')}}/themes/images/twitter.png" title="twitter" alt="twitter"/></a>
				<a href="https://www.youtube.com/channel/UCw7ghcYfjcyqvXWrCjILguQ"><img width="60" height="60" src="{{URL::asset('resources/css/fontend')}}/themes/images/youtube.png" title="youtube" alt="youtube"/></a>
			</div>
		</div>
		<p class="pull-right" style="font-style: italic;">&copy; Công ty TNHH Thương Mại Điện Tử H-Tech Shop</p>
    </div><!-- Container End -->
</div>
<!-- Placed at the end of the document so the pages load faster ============================================= -->
<script src="{{URL::asset('resources/css/fontend')}}/themes/js/jquery.js" type="text/javascript"></script>
<script src="{{URL::asset('resources/css/fontend')}}/themes/js/bootstrap.min.js" type="text/javascript"></script>
<script src="{{URL::asset('resources/css/fontend')}}/themes/js/google-code-prettify/prettify.js"></script>

<script src="{{URL::asset('resources/css/fontend')}}/themes/js/bootshop.js"></script>
<script src="{{URL::asset('resources/css/fontend')}}/themes/js/jquery.lightbox-0.5.js"></script>

<!-- Themes switcher section ============================================================================================= -->

<span id="themesBtn"></span>
<style>
    .text {
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 1; /* number of lines to show */
        -webkit-box-orient: vertical;
     }
</style>
